package tableaux;

public class Tableaux {
 public static void main (String [] args) {
	 
	 int tab[]; // tableau de type int avec la variable "tab" 
	 // tab est un tableau qui contient des int 
	 
	 tab= new int [5]; // instanciation de lobjet tab avec 5 cases 
	 tab[0]= 2; 	 //  0 est l'index  et le 2 est la valeur 
	 tab[2] = 4;
	 
	 
	 System.out.println(tab); //  resultat : | [I@3b22cdd0 | = adresse mémoire du tableau 
	 // [I@3b22cdd0 un resultat de ce style peut venir d'un tableau ou d'un objet 
	 
	 String tab1[];
	 tab1= new String [5];
	 System.out.println(tab1); // resultat : | [Ljava.lang.String;@1e81f4dc |
	 
	 boolean tab2 [];
	 tab2 = new boolean [5];
	 
	 System.out.println(tab2); // resultat : | [Z@4d591d15  |
	 System.out.println(tab2[0]); // resultat = false 
	 
	 for(int i = 0 ; i <tab.length; i++) { // la boucle commence à 0 et fait la meme longueur que le tableau elle avance de 1 a chaque fois
	 System.out.println(tab[i]); // resultat : 2 "/n" 0 "/n" 4 "/n" 0 "/n" 0                   "/n" (aller a la ligne) 
	 // affiche chaque élément du tableau 
	 }
	 
	 int tab3[]; // tableau de type int avec la variable "tab" 
	 // tab est un tableau qui contient des int 
	 int j= 5; // initialisation de la variable de type int 
	 
	 tab3= new int [j]; // instanciation de lobjet tab avec 5 cases 
	 tab3[0]= (int)(Math.random()*1000); //	0 est l'index et Mathrandom la valeur
	 tab3[1]= (int)(Math.random()*1000); //	1 est l'index et Mathrandom la valeur
	 tab3[2]= (int)(Math.random()*1000); //	2 est l'index et Mathrandom la valeur
	 tab3[3]= (int)(Math.random()*1000); //	3 est l'index et Mathrandom la valeur
	 tab3[4]= (int)(Math.random()*1000); //	4 est l'index et Mathrandom la valeur
	 for(j = 0 ; j <tab3.length; j++) { // j passe par chaque élement de tab3 en commencant par i 
System.out.println(tab3[j]); // j'affiche 
 /* affiche par exemple 
896
54
882
499
64
  */
	 
 }
}
}