package arraylist;

import java.util.ArrayList; 

public class ArraylistSuit {
	public static void main (String []args) {
		
		ArrayList<String> array = new ArrayList();
		
		array.add("yamaha"); // permet d'ajouter un element // la méthode set permet de modifier un element a l'indice donné 
		array.add("mercedes");
		array.add("bmw");
		array.add("audi");
		
		// pour afficher l'ensemble des élements
		// pour chaque élement trouver au niveau de mon tableau 
		for(String item: array) {
		System.out.println(item); // afficher ces élements  result : yamaha mercedes bmw audi
		
		}
		
	System.out.println("The first result is   "+array.contains("yamaha"));  // result : true // est ce que le tableau contient (contains) "yamaha" 
	System.out.println("The second result is " + array.contains("yamah"));  // result : false // est ce que le tableau contient (contains) "yamah" 
	System.out.println("The indexOf result is " + array.indexOf("yamaha"));  // result: 0 // il retourne l'indice de la premiere occurence 
	// des qu'il va trouver l'indice de la premiere occurence  yamaha il va s'arreter 
	// lorsqu'il ne trouve pas il retourne -1 
	
	array.set(0, "renault"); // modifie l'élement a l'indice 0 par "renault"
	
	System.out.println(array.get(0)); // affiche le premier element 
	//System.out.println(array.get(100)); // erreur 
	
	array.add(0 , "yamaha"); // je rajoute "yamaha" a l'indice 0 
	System.out.println(array.get(0)+ "   " + array.get(1));  // yamaha renault , yamaha a poussé renault vers l'indice 1 

	
	

	

		
	}

}
