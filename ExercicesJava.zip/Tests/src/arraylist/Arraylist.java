package arraylist;
import java.util.ArrayList; // importer la classe ArrayList
public class Arraylist {

	
	public static void main(String []args) {
		
		         //type de données stockées dans le  tableau dynamique / elle doit etre d'un type évolué (String, Integer)
		ArrayList<Integer> tableau= new ArrayList<Integer>(); // tableau dynamique
		tableau.add(5);
		tableau.add(25);
		tableau.add(15);
		tableau.add(125);
		System.out.println(tableau.get(0)); //result : 5  acceder a un element , recuperer la valeur a un indice donné 
		
		tableau.clear(); // supprimer(remove) tous  les élements d'un tableau(array) 
		
		if( tableau.isEmpty()) {
			
			System.out.println("Tableau vide ! ");
			
		}
		tableau.add(5);
		tableau.add(25);
		tableau.add(15);
		tableau.add(125);
		tableau.remove(0);
		                                                      // 25 , 5 a été supprimé //     position 1 =  15
		System.out.println("l'élement a la position 0 est  " + tableau.get(0)+ "  l'élement à la position 1 est " + tableau.get(1));
	
		
		
		System.out.println(tableau.get(0)); //result : 5  acceder a un element , recuperer la valeur a un indice donné 


		
		
		
		ArrayList<Integer> tableau2= new ArrayList<Integer>(); // tableau dynamique
		tableau2.add(5); // ajouté une valeur(un element) =  5  au tableau 
		tableau2.set(0, 128); // result : 128 // 0 = position de l'élement , modifier un element a un indice donné

		System.out.println(tableau2.size()); // taille  ///////// valeur = 1 
		System.out.println(tableau2.get(0)); // result : 5  acceder a un element , recuperer la valeur(value) a un indice donné
		//System.out.println(tableau.set()); // mettre une valeur (value)
		System.out.println(Integer.parseInt("2"+1)); // result : 21  // parsInt pour convertir une chaine de caractere en entier 
		System.out.println(Integer.parseInt("2") + 1); // result : 3 // parsInt pour convertir une chaine de caractere en entier 

		
	}
}
