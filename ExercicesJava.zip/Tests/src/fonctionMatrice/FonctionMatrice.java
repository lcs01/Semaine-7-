package fonctionMatrice;

import java.util.Arrays;

// on donne n'importe quel matrice de type entier 
public class FonctionMatrice {
	
	                               // parametre 
	public static int [][] matrice (int taille) {
		
		
		int [][]tab= new int [taille][taille]; // je génére un tableau à double dimension matrice de 0 a 100 = 10 * 10
		//taille =(int)(Math.random()+1000);
		  for (int i = 0 ; i <tab.length; i++) {
		        for (int j = 0 ; j <tab[i].length; j++) { //
		        
		        	tab[i][j]+=nbAleatoire(100);
		        	System.out.println("  i =  " + i + "  j  = " + j );
		        	System.out.println("  Table de  i " + Arrays.toString(tab[i]));
		        	System.out.println(" élement i j " + tab[i][j]);
		        }
		        }
		
		
		
		return
			tab;
	}
	                             // parametre 
    public static void affichage(int [][]tab) { // void = vide 
    for (int i = 0 ; i <tab.length; i++) {
    	int[]ligne = tab[i];
        for (int j = 0 ; j <tab.length; j++) { // FAUX = tab.length(); //   il faut donner a j le nombre de colonne grace à la postion 

    	System.out.println(tab[i][j]+ "");
    }
        System.out.println();
        }
    }
    
    public static int nbAleatoire (int max) {
    	
    	return   (int)(Math.random()*max);
    	
    }
	
	//Arrays.toString(tab)
public static void main (String []args) {
	
	int[][]matrice= matrice(3);
    affichage(matrice);
	
	
}
}


