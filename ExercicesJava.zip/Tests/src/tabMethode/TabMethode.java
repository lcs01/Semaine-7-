package tabMethode;


public class TabMethode {
	
	/*
	* Crée un tableau avec des nb aléatoires compris entre 0 et 100
	* @param tailleTab
	* @return
	*/
	    public static int[] randomTab(int tailleTab) {
	        int[] tab = new int[tailleTab];
	        for(int i=0; i<tab.length; i++) {
	            tab[i] = (int) (Math.random() * 100);
	        }
	        return tab;


	    }
	/*
	 * Affiche un tableau avec gestion de la dernière virgule
	 * @param tab
	 */
	    public static void affiche(int[] tab) {
	        System.out.print("[");
	        for(int i=0; i<tab.length; i++) {

	            System.out.print(tab[i]);
	            if (i != tab.length -1) {
	            System.out.print(", ");
	            }
	        }
	        System.out.print("]");

	        System.out.println();


	    }
	    /**
	     * Affiche un tableau avec gestion de la première virgule
	     * @param tab
	     */
	    public static void affiche2(int[] tab) {
	        System.out.print("[");
	        for(int i=0; i<tab.length; i++) { 

	            if (i != 0) {
	            System.out.print(", ");
	            }
	            System.out.print(tab[i]);
	        }
	        System.out.print("]");

	        System.out.println();


	    }


	    public static void main(String[] args) {
	        int[] tabTest = randomTab(2+5); //fonction qui a un retour = variable

	        affiche(tabTest); //fonction sans retour

	        affiche2(randomTab(2));
	    }

	}
  


