package testExercice2I1;
/*Exercice1
Écrire un programme qui lit un mot au clavier et qui indique combien de fois sont
présentes chacune des voyelles a, e, i, o, u ou y, que celles-ci soient écrites en
majuscules ou en minuscules, comme dans cet exemple :
Exemple d’exécution :
Donnez un mot : Anticonstitutionnellement
il comporte
1 fois la lettre a
3 fois la lettre e
3 fois la lettre i
2 fois la lettre o
1 fois la lettre u
0 fois la lettre y*/

import java.util.Scanner;
public class testExercice2I1 {



		public static void main (String []args) {
			System.out.println("Saisissez un mot : ");
			Scanner saisie = new Scanner(System.in); 
			String[] saisie1= saisie.nextLine().
			for(int i = 0 ; i<saisie1.length(); i++){

			
			char []alphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','y','z'};
int compteurA = 0 ; 
			if(a == alphabet[0]) {
			compteurA++;
			System.out.println("Nombre de A dans le mot  = "+ compteurA);
			}
			}
			// je recupere la 
			
		//	for(int i = 0 ; i<saisie1.length(); i++){
		//	char []saisie2= saisie1.charAt(i);
	//		}
	//		System.out.println("premier caractere saisie  :" + saisie2);

		/*	for(int i = 0; i<saisie.length ; i++ ) {
				char [] saisie1= {};
			} */
			
			
/*			for(int i = 0; i<alphabet.length ; i++ ) {
			
			switch(saisie1==alphabet[i]) {
			case 'a': 
			}	
			break;
			}*/
		

		}

}
