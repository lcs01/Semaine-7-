package entiers;


public class Entiers{ // une classe sert à stocker tous les élements 
	
	/**
	 * 
	 * @param tableauEntier
	 * @return
	 */

	public static int maMethode(int[]tab) { 

		 int maxVal= 0; // instancie la variable de type int 
			
		for(int i = 0 ; i <tab.length ; i++) {
			// i est égale à la longueur du tab 
			
			
			if(tab[i]>maxVal) {
				// si la position actuelle de i est plus grand que maxVal
				maxVal = tab[i];
				// maxVal aura la valeur du chiffre en position i 
			}	
				
			}
			
			 return maxVal;
				// la methode return à maxVal 
				

			
	
  }
	
			/* mettre i dans différentes variables */
			/* si une des variables est plus grande que les autres afficher "entier la plus grand */
			 /* i=0 = maxi */ /* si i devient plus grand que maxi i devient maxi  */
		//	System.out.println(tableauEntier.length -1);
	/*	try {
			
		}
catch (Exception e) {
	System.err.println("Erreur");
} */
	public static void main (String[]args) {

		int []tableauEntier = {0,1,2,1222,100,5,6,21,70,9,99999999,20102101}; // on instancie un tableau 
		System.out.println(maMethode(tableauEntier)); 
		// affiche le resultat de la methode qui trouve le plus grand chiffre dans le tableauEntier
	}
	
}