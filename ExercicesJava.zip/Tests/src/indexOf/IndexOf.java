package indexOf;

public class IndexOf {


	    public static void main(String[] args) {

	        String[] tab = new String [10];// Déclaration d'un tableau de 10 String

	        tab[0] = "jaune@gmail.com";    
	        tab[1] = "bleu@orange.com";
	        tab[2] = "vert@gmail.com";
	        tab[3] = "violet@hotmail.com";
	        tab[4] = "rouge@gmail.com";                        //Tableau rempli 
	        tab[5] = "noir@free.com";
	        tab[6] = "orange@hotmail.com";
	        tab[7] = "blanc@orange.com";
	        tab[8] = "rose@gmail.com";
	        tab[9] = "gris@free.com";
	int i ; 
	        for ( i = 0; i < tab.length; i++) {
	            //System.out.println(tab[i].substring(tab[i].indexOf("@")));

	       System.out.println(tab[i].substring(tab[i].lastIndexOf("m")));
	        
	    }
	}
}
