package exercice2I1;

import java.util.Scanner;

/*Exercice1
Écrire un programme qui lit un mot au clavier et qui indique combien de fois sont
présentes chacune des voyelles a, e, i, o, u ou y, que celles-ci soient écrites en
majuscules ou en minuscules, comme dans cet exemple :
Exemple d’exécution :
Donnez un mot : Anticonstitutionnellement
il comporte
1 fois la lettre a
3 fois la lettre e
3 fois la lettre i
2 fois la lettre o
1 fois la lettre u
0 fois la lettre y*/
public class Exercice2I1 {
	public static void main (String []args) {
		char []alphabet = {'a','e','i','o','u','y'}; // j'instancie un tableau de char contenant les voyelles 
		
		
     int compteurA= 0;
     int compteurE= 0;
     int compteurI= 0;
     int compteurO= 0;
     int compteurU= 0;
     int compteurY= 0;
    
		System.out.println("Saisissez un mot : ");
		Scanner saisie = new Scanner(System.in); 
		String word = saisie.nextLine();
		
		int a = word.length();
		char[] tab = new char[a];
		 int i  ;
		for(i = 0; i < a;i++){
		     tab[i] = word.charAt(i);
		
		
		switch (tab[i]) {
		
		case 'a' : 
			compteurA ++ ;
			break;
		case 'e' : 
			compteurE ++ ;
			break;
		case 'i' : 
			compteurI ++ ;
			break;
		case 'o' :
			compteurO ++ ;
			break;
		case 'u' : 
			compteurU ++ ;
			break;
		case 'y' : 
			compteurY ++ ;
		default:
			
		}
		
		}
		System.out.println("Le nombre de a est de : " + compteurA);
		System.out.println("Le nombre de e est de : " + compteurE);
		System.out.println("Le nombre de i est de : " + compteurI);
		System.out.println("Le nombre de o est de : " + compteurO);
		System.out.println("Le nombre de u est de : " + compteurU);
		System.out.println("Le nombre de y est de : " + compteurY);
		

		

	/*	for(int i = 0 ; i<saisie2.length(); i++) {
			System.out.println(saisie2.charAt(i));
			char []saisie4= saisie2.charAt(i);
			
			}
		
		*/
	
	}
}
