package exercice2I5;

import java.util.Scanner;

/*Exercice 5
Écrire un programme permettant de remplir un tableau de 5 éléments, ensuite calcule et
affiche la somme des éléments de ce tableau.*/
public class Exercice2I5 {
	public static void main (String [] args) {
		
		System.out.println("Saisir un chiffre : ");
		Scanner saisie = new Scanner(System.in);
		int saisie1 = saisie.nextInt();
		
		
		System.out.println("Saisir un deuxieme chiffre : ");
		saisie = new Scanner(System.in);
		int saisie2 = saisie.nextInt();
		
		
		System.out.println("Saisir un troisieme chiffre : ");
		 saisie = new Scanner(System.in);
		int saisie3 = saisie.nextInt();
		
		System.out.println("Saisir un quatrieme chiffre : ");
		saisie = new Scanner(System.in);
		int saisie4 = saisie.nextInt();
		
		System.out.println("Saisir un cinquieme chiffre : ");
		saisie = new Scanner(System.in);
		int saisie5 = saisie.nextInt();
	
		int [] saisietab = {saisie1,saisie2,saisie3,saisie4,saisie5};
		
		System.out.println("Le résultat est " + (saisietab[0]+saisietab[1]+saisietab[2]+saisietab[3]+saisietab[4]));
		
		
		
	}

}
