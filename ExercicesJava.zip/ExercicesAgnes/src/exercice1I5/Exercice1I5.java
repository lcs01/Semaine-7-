package exercice1I5;
/*Exercice 5
Générer trois nombres aléatoires compris entre 0 et 1000, puis vérifier si vous avez deux
nombres pairs suivis par un nombre impair. Si ce n’est pas le cas, recommencer jusqu’à
ce vous ayez la combinaison pair, pair, impair. Afficher ensuite le nombre d’essais
nécessaires pour obtenir cette combinaison.
Indice : la classe Math propose la méthode statique random qui génère un nombre
aléatoire compris entre 0 et 1.
Exemple : double nb=Math.random();          */



public class Exercice1I5 {
	public static void main (String[]args) {

		int compteur = 0; // j'instancie une variable appelé compteur  de type int 
		boolean verif = true; 


		while(verif) {// tant que verif est true 
			// j'instance  3 variables contenant chacune un nombre aléatoire compris entre 0 et 1000
			int nb1 = (int) Math.floor(Math.random()* 1001);
			int nb2 = (int) Math.floor(Math.random()* 1001);
			int nb3 = (int) Math.floor(Math.random()* 1001);

			int [] nbAleatoire= {nb1,nb2, nb3 };  // je génere un tableau contenant ces nombres 

			if (nbAleatoire[0]% 2== 0 && nbAleatoire[1]% 2== 0&&nbAleatoire[2]%2!=0) {
				System.out.println(nb1 + " " + nb2 + " " + nb3);
				verif = false ;
			}
			compteur++;}


		System.out.println("il a trouvé en"+ compteur + "essai" );

		/*    	
    			if (nbAleatoire[0]% modulo== 0 && nbAleatoire[1]% modulo== 0&&nbAleatoire[2]%modulo!=0) {
       				 // si le premier élement de nbAleatoire est pair le deuxieme est pair et le troisieme est impair alors  : 
       				System.out.println("Le premier chiffre est pair : " + nbAleatoire[0]+" / Le deuxieme chiffre est pair : " + nbAleatoire[1]+" /  Le troisième nombre est impair :  " + nbAleatoire[2]); // afficher 

    				    			}*/
	}}
/*		if(nbAleatoire[1]% test== 0) {
        				System.out.println("Le deuxieme nombre est pair :  " + nbAleatoire[1]);


            				else {
            					System.out.println("Le troisième nombre est pair" + nbAleatoire[2]);
            				}

    				}*/



// token = symbole


/*		if(nbAleatoire[1]% test== 0) {
System.out.println("Le deuxieme nombre est pair :  " + nbAleatoire[1]);


	else {
		System.out.println("Le troisième nombre est pair" + nbAleatoire[2]);
	}

}*/
