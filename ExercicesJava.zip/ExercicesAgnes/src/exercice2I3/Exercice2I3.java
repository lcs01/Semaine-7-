package exercice2I3;

import java.util.Scanner;

/*Exercice 3
Écrire une fonction permettant de calculer le factoriel d’un entier saisi au clavier.
Sachant que :
N ! = N * (N – 1) !
1! = 0! = 1
Exemple d’exécution :
Donnez la valeur de n :
5
Le factoriel de 5 est :120*/  // 1*2*3*4*5 = 120 
//Le factoriel de 6 est :720*/  // 1*2*3*4*5*6 = 720 
public class Exercice2I3 {
	public static void main(String []args) {
		
	 	System.out.println("Saisir la valeur d'un entier  : ");  // jaffiche 
	 	Scanner saisie = new Scanner(System.in); // j'instancie l'objet Scanner
	 	int entier = saisie.nextInt(); // j'initialise la variable "entier" de type int qui contient la saisie du Scanner 
	 	
	 	int factorielle = 1 ; 
	 	
	 	if(entier != 0 ) { // si le chiffre choisit est différent de 0 
	 		for(int i = 1 ; i < entier+1; i++  ) { // pour l'i vaut 1 , l'i  est plus petit que la valeur de la variable "entier" et l'i  s'incrémente 
	 		
	 			factorielle = factorielle* i; 
	 			// je recupere i ,  exemple : si  entier = 5 alors i = 1 2 3 4 5 
	 			// entier = 3  alors i = 1 2 3 donc le factorielle est 1*2*3 
	 		    
	 			
	 			
	 			
		 		// il ny a pas de return dans le main 

	 			}
	 	System.out.println(factorielle);
	 		
	 		}
	 		
	 		
	 	}
	 	
	 	
		
		
	}

