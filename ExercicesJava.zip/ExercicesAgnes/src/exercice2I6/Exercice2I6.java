package exercice2I6;

public class Exercice2I6 {

}
