package exercice1I6;

import java.util.Scanner;

import javax.swing.Timer;

/* Exercice 6
Générer un nombre aléatoire compris entre 0 et 1000. Demander ensuite à l’utilisateur de
deviner le nombre choisi par l’ordinateur. Il doit saisir un nombre compris entre 0 et 1000
lui aussi. Comparer le nombre saisi avec celui choisi par l’ordinateur et afficher sur la
console « c’est plus » ou « c’est moins » selon le cas. Recommencer jusqu’à ce que
l’utilisateur trouve le bon nombre. Afficher alors le nombre d’essais nécessaires pour
trouver la bonne réponse.
Indice : pour récupérer les caractères saisis au clavier, nous avons à notre disposition le
flux System.in. Malheureusement, celui-ci ne propose que des fonctions rudimentaires
pour la récupération des saisies de l’utilisateur (lecture caractère par caractère). Pour une
utilisation plus confortable, il vaut mieux utiliser un objet Scanner. Nous aurons ainsi à
notre disposition une série de fonctions permettant la récupération d’entiers, de float, de
chaînes de caractères... Ces fonctions sont nommées nextxxxx où xxxx doit être remplacé
par le type de données que l’on souhaite obtenir, par exemple nextInt pour un entier,
nextLine pour une chaîne de caractères, etc.
String chaine;
Scanner sc;
sc=new Scanner(System.in);
chaine = sc.nextLine();
*/
public class Exercice1I6 {
	public static void main (String[]args) {

		// j'instancie une variable nommé chiffre aleatoire de type int
		//j'utilise la méthode Math.random pour générer un chiffre aleatoire
		int chiffrealeatoire = 10 ;//(int)(Math.random()*1000); 
		
boolean verif = false; 
		
		
		System.out.println("Devines quelle chiffre j'ai choisi entre 0 et 1000: ");
		
		//j'instancie l'objet(méthode) Scanner dans une variable usernumber ? 
		//L'utilisateur peut rentrer une saisie 
		Scanner chiffreutilisateur = new Scanner (System.in); 
		// je stocke la saisie dans une variable int 
		int chiffreutilisateur1= chiffreutilisateur.nextInt();
		// si le chiffreutilisateur1 est plus petit que 1000 ou plus grand que 0 
		//je le compare à chiffrealeatoire
		
		int compteur = 0 ; // j'instancie une variable nommée compteur de type int 
		while(verif == false) {	
			// si chiffreutilisateur1 est égale a chiffrealeatoire 
			if(chiffreutilisateur1 == chiffrealeatoire) {
				System.out.println("You win"); // alors j'affiche "" 
				System.out.println("Nombre de tentatives : " + compteur );
				verif = true; 
			}
			// sinon si chiffre utilisateur1 est plus petit que chiffrealeatoire
			
				
			
			if (chiffreutilisateur1<chiffrealeatoire) {
				System.out.println("C'est plus ! Saisissez un nouveau chiffre :  ");
				compteur++;
				verif= false; 
		    chiffreutilisateur = new Scanner (System.in); 
				chiffreutilisateur1= chiffreutilisateur.nextInt();
	    
			}
			else if (chiffreutilisateur1>chiffrealeatoire) {
				System.out.println("C'est moins ! ");
				compteur++;
				verif = false;
				chiffreutilisateur = new Scanner (System.in); 
				chiffreutilisateur1= chiffreutilisateur.nextInt();

			}
		
			

			}
		}



}
