package exercice2I4;
import java.util.ArrayList;
import java.util.Scanner; 
/*Exercice 4
La suite de Fibonacci est définie par :

Ecrire une fonction calculant le Nième élément de la suite.
Exemple d’exécution :

// tableau 
1= 1 +2 = 3 +2= 5+3 = 8 

nombre = 1 ; 
nombre + (nombre-1) = nombre2 = 2 
nombre2 + (nombre2++) = nombre3 = 3 
nombre3 + (nombre3++) = nombre4 = 5

 
 


Donnez la valeur de n :
5
le 5ième élément de la suite est : 8*/
public class Exercice2I4 {
	public static void main (String []args ) {
		

		System.out.println("Donnez la valeur de la variable   : ");
		// j'instancie un tableau dynamique avec l'ArrayList Fibonnaci de type évolué Integer 

		ArrayList<Integer> tableau = new ArrayList<Integer>();
		
		
		Scanner saisie= new Scanner (System.in); // je recupere la saisie 
		

		int valeur = saisie.nextInt() ; // je l'initie dans une variable de type int 
		int nombre = valeur; 
		
		// j'additionne la valeur de  cette variable à sa valeur + 1
		
		if(valeur==2) {
		valeur = nombre +(nombre-1);
		
		
		
		System.out.println(valeur); // jaffiche le result 
		}
		for(int item: tableau) {
		
		
		
		
		System.out.println(tableau.get(item));}
		
		}
	}


