package exercice1I7;

public class Exercice1I7 {
	public static void main (String []args) {
		
		
		localdate();
		
		
		
		
		
		
	}

}
