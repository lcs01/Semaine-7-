package exercice2I2;

import java.util.Scanner;

/*Exercice 2
Écrire un programme qui lit un entier au clavier et qui l’affiche verticalement comme dans
cet exemple :
Exemple d’exécution :
Donnez un nombre entier : 785412
7
8
5
4
1
2*/
public class Exercice2I2 {

	public static void main(String[]args) {
		System.out.println("Saisir un nombre entier : ");
		Scanner saisie = new  Scanner(System.in);
		String saisie1= saisie.nextLine();
		for(int i = 0 ; i<saisie1.length(); i++) {
		System.out.println(saisie1.charAt(i));
		}
		
		
		
	}
}
